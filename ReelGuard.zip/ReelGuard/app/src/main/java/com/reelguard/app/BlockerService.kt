package com.reelguard.app

import android.accessibilityservice.AccessibilityService
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.net.Uri
import android.os.SystemClock
import android.provider.Settings
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast

class BlockerService : AccessibilityService() {

    private var lastActionAt = 0L
    private var streak = 0
    private var lastScanAt = 0L
    private var lastGuardAt = 0L
    private var ourSettingsSeenAt = 0L

    // Instagram state
    private var igPrev = IgScreen.OTHER
    private var inDmReel = false
    private var dmReelSince = 0L

    private val debuggable: Boolean
        get() = (applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0

    /** Words on "Force stop?", "Uninstall?", "Deactivate?" style dialogs (English, French, Arabic). */
    private val dangerWords = listOf(
        "force stop", "uninstall", "deactivate", "clear storage", "clear data", "turn off",
        "forcer l", "désinstaller", "désactiver", "effacer les données", "vider",
        "فرض الإيقاف", "إلغاء التثبيت", "إلغاء التنشيط", "مسح البيانات", "حذف"
    )

    override fun onServiceConnected() {
        super.onServiceConnected()
        Starter.start(this)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        val pkg = event.packageName?.toString() ?: return

        // Leaving Instagram resets its state machine.
        if (pkg != Targets.IG && event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            igPrev = IgScreen.OTHER
            inDmReel = false
        }

        when (pkg) {
            Targets.YT -> if (Prefs.getBool(this, Prefs.YT_SHORTS)) handleYouTube(event)
            Targets.FB, Targets.FB_LITE -> if (Prefs.getBool(this, Prefs.FB_REELS)) handleFacebook(event)
            Targets.IG -> if (Prefs.getBool(this, Prefs.IG_ENABLED)) handleInstagram(event)
            else -> guardSettings(event)
        }
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        notifyDisabled()
        Starter.scheduleRestart(this)
        return super.onUnbind(intent)
    }

    // ---------------------------------------------------------------- YouTube

    private fun handleYouTube(e: AccessibilityEvent) {
        if (e.eventType == AccessibilityEvent.TYPE_VIEW_SCROLLED) return
        if (!shouldScan(e)) return
        val snap = snapshotOf(Targets.YT, e) ?: return
        debugLog("YT", snap)
        if (Detectors.isYouTubeShorts(snap)) leave("YouTube Shorts")
    }

    // ---------------------------------------------------------------- Facebook

    private fun handleFacebook(e: AccessibilityEvent) {
        if (e.eventType == AccessibilityEvent.TYPE_VIEW_SCROLLED) return
        if (!shouldScan(e)) return
        val pkg = e.packageName?.toString() ?: return
        val snap = snapshotOf(pkg, e) ?: return
        debugLog("FB", snap)
        if (Detectors.isFacebookReels(snap)) leave("Facebook Reels")
    }

    // ---------------------------------------------------------------- Instagram

    private fun handleInstagram(e: AccessibilityEvent) {
        if (e.eventType == AccessibilityEvent.TYPE_VIEW_SCROLLED) {
            // A reel opened from a DM may be watched, but not swiped to the next one.
            if (inDmReel &&
                SystemClock.uptimeMillis() - dmReelSince > 900 &&
                isPagerScroll(e)
            ) {
                inDmReel = false
                leave("scrolling reels")
            }
            return
        }
        if (!shouldScan(e)) return

        val snap = snapshotOf(Targets.IG, e) ?: return
        val screen = Detectors.instagramScreen(snap)
        debugLog("IG/$screen", snap)

        val blockFeed = Prefs.getBool(this, Prefs.IG_FEED)
        val blockReels = Prefs.getBool(this, Prefs.IG_REELS)
        val blockExplore = Prefs.getBool(this, Prefs.IG_EXPLORE)
        val allowDmReels = Prefs.getBool(this, Prefs.IG_DM_REELS)

        var block = false
        when (screen) {
            IgScreen.FEED -> block = blockFeed
            IgScreen.REELS -> block = blockReels
            IgScreen.EXPLORE -> block = blockExplore
            IgScreen.REEL_VIEWER -> {
                if (blockReels) {
                    if (allowDmReels && igPrev == IgScreen.DM) {
                        if (!inDmReel) {
                            inDmReel = true
                            dmReelSince = SystemClock.uptimeMillis()
                        }
                    } else {
                        block = true
                    }
                } else {
                    inDmReel = false
                }
            }
            else -> {}
        }

        if (screen != IgScreen.REEL_VIEWER) {
            inDmReel = false
            // Hysteresis: an unrecognised screen right after a DM keeps counting as "DM",
            // so a shared reel can still be opened if DM detection is imperfect.
            if (!(screen == IgScreen.OTHER && igPrev == IgScreen.DM)) igPrev = screen
        }

        if (block) {
            inDmReel = false
            leave("Instagram", ::openInstagramDm)
        }
    }

    private fun isPagerScroll(e: AccessibilityEvent): Boolean {
        val id = e.source?.viewIdResourceName?.lowercase().orEmpty()
        val cls = e.className?.toString()?.lowercase().orEmpty()
        return id.contains("pager") || id.startsWith("clips_viewer") || cls.contains("viewpager")
    }

    private fun openInstagramDm(): Boolean = try {
        startActivity(
            Intent(Intent.ACTION_VIEW, Uri.parse("instagram://direct_inbox"))
                .setPackage(Targets.IG)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        )
        true
    } catch (ex: Exception) {
        false
    }

    // ---------------------------------------------------------------- password guard

    /**
     * Any Settings / uninstall / app-manager screen that shows this app's name needs the
     * password first. A "Force stop?" or "Deactivate?" dialog that opens from such a page
     * (it does not show the name) is caught too. Best effort: it stops impulsive disabling,
     * not a determined person using safe mode or ADB.
     */
    private fun guardSettings(e: AccessibilityEvent) {
        val pkg = e.packageName?.toString() ?: return
        if (pkg !in Targets.GUARDED) return
        if (e.eventType == AccessibilityEvent.TYPE_VIEW_SCROLLED) return
        if (!Prefs.getBool(this, Prefs.PROTECT) ||
            !Prefs.hasPassword(this) ||
            Prefs.isUnlocked(this)
        ) return
        val now = SystemClock.uptimeMillis()
        if (now - lastGuardAt < 2500) return
        val root = rootInActiveWindow ?: return

        val mentionsUs =
            !root.findAccessibilityNodeInfosByText(getString(R.string.app_name)).isNullOrEmpty()
        var trip = mentionsUs
        if (mentionsUs) {
            ourSettingsSeenAt = now
        } else if (now - ourSettingsSeenAt < 20_000) {
            val isDialog = e.className?.toString()?.contains("dialog", ignoreCase = true) == true
            trip = isDialog ||
                dangerWords.any { !root.findAccessibilityNodeInfosByText(it).isNullOrEmpty() }
        }
        if (!trip) return

        lastGuardAt = now
        performGlobalAction(GLOBAL_ACTION_HOME)
        try {
            startActivity(
                Intent(this, UnlockActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (ex: Exception) {
            // Home was already pressed; that alone keeps the page closed.
        }
    }

    // ---------------------------------------------------------------- helpers

    private fun shouldScan(e: AccessibilityEvent): Boolean {
        val now = SystemClock.uptimeMillis()
        if (e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            lastScanAt = now
            return true
        }
        if (now - lastScanAt < 150) return false
        lastScanAt = now
        return true
    }

    private fun snapshotOf(pkg: String, e: AccessibilityEvent): Snapshot? {
        val root = rootInActiveWindow ?: return null
        if (root.packageName?.toString() != pkg) return null
        val cls = if (e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED)
            e.className?.toString().orEmpty() else ""
        return Detectors.snapshot(root, cls)
    }

    /** Close the offending screen. Falls back to Home if it keeps coming back. */
    private fun leave(label: String, redirect: (() -> Boolean)? = null) {
        val now = SystemClock.uptimeMillis()
        if (now - lastActionAt < 800) return
        streak = if (now - lastActionAt < 5000) streak + 1 else 1
        lastActionAt = now
        Toast.makeText(applicationContext, "ReelGuard blocked $label", Toast.LENGTH_SHORT).show()
        if (streak >= 4) {
            streak = 0
            performGlobalAction(GLOBAL_ACTION_HOME)
            return
        }
        if (redirect != null && redirect()) return
        performGlobalAction(GLOBAL_ACTION_BACK)
    }

    private fun debugLog(tag: String, s: Snapshot) {
        if (!debuggable) return
        Log.d("ReelGuard", "$tag class=${s.className} selected=${s.selectedIds} descs=${s.selectedDescs} ids=${s.ids.distinct().take(80)}")
    }

    private fun notifyDisabled() {
        val nm = getSystemService(NotificationManager::class.java) ?: return
        nm.createNotificationChannel(
            NotificationChannel("status", "Protection status", NotificationManager.IMPORTANCE_HIGH)
        )
        val pi = PendingIntent.getActivity(
            this, 0, Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = android.app.Notification.Builder(this, "status")
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .setContentTitle("ReelGuard is turned off")
            .setContentText("Tap to turn the accessibility service back on.")
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        try {
            nm.notify(1, n)
        } catch (ex: SecurityException) {
            // notification permission not granted; nothing else to do
        }
    }
}
