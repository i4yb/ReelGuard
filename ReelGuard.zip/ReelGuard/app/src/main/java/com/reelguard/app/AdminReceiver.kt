package com.reelguard.app

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent

/** Registering as a device admin means ReelGuard can't be uninstalled until admin is removed first. */
class AdminReceiver : DeviceAdminReceiver() {
    override fun onDisableRequested(context: Context, intent: Intent): CharSequence? =
        "Turning this off lets ReelGuard be uninstalled and ends your reel blocking."
}
