package com.reelguard.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.admin.DevicePolicyManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.WindowManager
import android.widget.CompoundButton
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton

class MainActivity : AppCompatActivity() {

    private class Perm(
        val title: String,
        val why: String,
        val granted: () -> Boolean,
        val request: () -> Unit
    )

    private class PermRow(val perm: Perm, val status: TextView, val button: MaterialButton)

    private val rows = mutableListOf<PermRow>()
    private val igSubSwitches = mutableListOf<SwitchCompat>()
    private lateinit var banner: TextView
    private var built = false
    private var reverting = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)

        if (!Prefs.hasPassword(this)) {
            startActivity(Intent(this, SetupPasswordActivity::class.java))
            finish()
            return
        }
        build()
        built = true
    }

    override fun onResume() {
        super.onResume()
        if (!built) return
        Starter.start(this)
        if (!Prefs.isUnlocked(this)) {
            startActivity(Intent(this, UnlockActivity::class.java))
            return
        }
        refresh()
    }

    override fun onUserInteraction() {
        super.onUserInteraction()
        if (built) Prefs.extendUnlock(this)
    }

    // ------------------------------------------------------------ UI

    private fun build() {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Ui.dp(context, 20), Ui.dp(context, 32), Ui.dp(context, 20), Ui.dp(context, 40))
        }

        col.addView(Ui.text(this, "ReelGuard", 28f, true))
        banner = Ui.text(this, "", 15f).apply { setPadding(0, Ui.dp(context, 8), 0, Ui.dp(context, 8)) }
        col.addView(banner)
        col.addView(Ui.button(this, "Grant next missing permission") { grantNext() })

        // Permissions
        col.addView(section("Permissions"))
        for (p in permissions()) {
            val status = Ui.text(this, "", 14f)
            val btn = Ui.button(this, "Grant") { p.request() }
            col.addView(Ui.text(this, p.title, 16f, true).apply { setPadding(0, Ui.dp(context, 12), 0, 0) })
            col.addView(Ui.text(this, p.why, 13f))
            col.addView(status)
            col.addView(btn)
            rows.add(PermRow(p, status, btn))
        }

        // YouTube
        col.addView(section("YouTube"))
        addSwitch(col, "Block Shorts", Prefs.YT_SHORTS)

        // Facebook
        col.addView(section("Facebook"))
        addSwitch(col, "Block Reels", Prefs.FB_REELS)

        // Instagram
        col.addView(section("Instagram"))
        col.addView(
            Ui.text(
                this,
                "DM-only mode: the app opens straight into your messages. Reels that friends send you can be opened, but not swiped to the next one.",
                13f
            )
        )
        val master = addSwitch(col, "Instagram DM-only mode", Prefs.IG_ENABLED)
        igSubSwitches += addSwitch(col, "Block main feed", Prefs.IG_FEED)
        igSubSwitches += addSwitch(col, "Block Reels tab", Prefs.IG_REELS)
        igSubSwitches += addSwitch(col, "Block search and Explore", Prefs.IG_EXPLORE)
        igSubSwitches += addSwitch(col, "Allow one reel sent by a friend (no scrolling)", Prefs.IG_DM_REELS)
        igSubSwitches.forEach { it.isEnabled = master.isChecked }

        // Commitment lock
        col.addView(section("Commitment lock"))
        col.addView(
            Ui.text(
                this,
                "Locks every setting and the off switch for a fixed time. While it runs, even your password will not open ReelGuard. " +
                    "Settings can't be changed and protection can't be turned off from inside the app until it ends. Choose carefully.",
                13f
            )
        )
        col.addView(Ui.button(this, "Lock for 1 hour") { confirmCommit(60L * 60_000L, "1 hour") })
        col.addView(Ui.button(this, "Lock for 24 hours") { confirmCommit(24L * 60L * 60_000L, "24 hours") })
        col.addView(Ui.button(this, "Lock for 7 days") { confirmCommit(7L * 24L * 60L * 60_000L, "7 days") })

        // Security
        col.addView(section("Security"))
        addSwitch(col, "Ask for password before opening Settings pages for this app", Prefs.PROTECT)
        col.addView(Ui.button(this, "Change password") {
            startActivity(Intent(this, SetupPasswordActivity::class.java))
        })
        col.addView(Ui.button(this, "Lock now") {
            Prefs.lock(this)
            finishAffinity()
        })

        setContentView(ScrollView(this).apply { addView(col) })
    }

    private fun section(title: String): TextView =
        Ui.text(this, title, 18f, true).apply { setPadding(0, Ui.dp(context, 28), 0, Ui.dp(context, 4)) }

    private fun addSwitch(parent: LinearLayout, label: String, key: String): SwitchCompat {
        val sw = SwitchCompat(this).apply {
            text = label
            textSize = 15f
            isChecked = Prefs.getBool(this@MainActivity, key, true)
            setPadding(0, Ui.dp(context, 10), 0, Ui.dp(context, 10))
        }
        sw.setOnCheckedChangeListener { v: CompoundButton, checked: Boolean ->
            if (reverting || !v.isPressed) return@setOnCheckedChangeListener
            if (!Prefs.isUnlocked(this)) {
                reverting = true
                v.isChecked = !checked
                reverting = false
                startActivity(Intent(this, UnlockActivity::class.java))
                return@setOnCheckedChangeListener
            }
            Prefs.setBool(this, key, checked)
            if (key == Prefs.IG_ENABLED) igSubSwitches.forEach { it.isEnabled = checked }
        }
        parent.addView(sw)
        return sw
    }

    private fun confirmCommit(durationMs: Long, label: String) {
        AlertDialog.Builder(this)
            .setTitle("Lock for $label?")
            .setMessage(
                "For $label you won't be able to change settings or turn ReelGuard off, even with your password. " +
                    "This can't be undone early."
            )
            .setPositiveButton("Lock") { _, _ ->
                Prefs.commit(this, durationMs)
                finishAffinity()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ------------------------------------------------------------ permissions

    private fun permissions(): List<Perm> = listOf(
        Perm(
            "Accessibility service (required)",
            "Lets ReelGuard see which screen is open in YouTube, Facebook and Instagram so it can close Shorts and Reels. " +
                "If the switch is greyed out: Settings > Apps > ReelGuard > ⋮ > Allow restricted settings, then try again.",
            { Access.isEnabled(this) },
            { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        ),
        Perm(
            "Display over other apps (required)",
            "Lets ReelGuard open the Instagram messages screen and the password prompt when a blocked screen appears.",
            { Settings.canDrawOverlays(this) },
            {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                )
            }
        ),
        Perm(
            "Device administrator (recommended)",
            "Stops ReelGuard from being uninstalled until you turn this off, which needs your password.",
            { adminActive() },
            { requestAdmin() }
        ),
        Perm(
            "Unrestricted battery (recommended)",
            "Keeps Android from stopping the blocker in the background. On Xiaomi, Huawei, Oppo, Vivo and Samsung phones also allow Autostart / 'Never sleeping apps' for ReelGuard in the phone's battery settings.",
            { batteryUnrestricted() },
            { requestBattery() }
        ),
        Perm(
            "Notifications (recommended)",
            "Shows the always-on 'ReelGuard is protecting you' notice and warns you if blocking gets switched off.",
            { notificationsGranted() },
            { requestNotifications() }
        ),
        Perm(
            "Self-repair via computer (optional, strongest)",
            "Lets ReelGuard switch its own accessibility service back on within seconds if it is turned off. " +
                "Needs a one-time command from a computer with USB debugging. The button copies it:\n" +
                ADB_COMMAND,
            { Access.canWriteSecure(this) },
            { copyAdbCommand() }
        )
    )

    private fun adminActive(): Boolean {
        val dpm = getSystemService(DevicePolicyManager::class.java)
        return dpm.isAdminActive(ComponentName(this, AdminReceiver::class.java))
    }

    private fun requestAdmin() {
        startActivity(
            Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                .putExtra(
                    DevicePolicyManager.EXTRA_DEVICE_ADMIN,
                    ComponentName(this, AdminReceiver::class.java)
                )
                .putExtra(
                    DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                    "Prevents ReelGuard from being uninstalled without turning this off first."
                )
        )
    }

    private fun notificationsGranted(): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED

    private fun requestNotifications() {
        if (Build.VERSION.SDK_INT >= 33) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
        }
    }

    private fun batteryUnrestricted(): Boolean =
        getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName)

    @SuppressLint("BatteryLife")
    private fun requestBattery() {
        startActivity(
            Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
        )
    }

    private fun copyAdbCommand() {
        val cm = getSystemService(ClipboardManager::class.java)
        cm.setPrimaryClip(ClipData.newPlainText("adb command", ADB_COMMAND))
        Toast.makeText(this, "Command copied. Run it from a computer with USB debugging on.", Toast.LENGTH_LONG).show()
    }

    private fun grantNext() {
        val next = rows.firstOrNull { !it.perm.granted() }
        if (next == null) {
            Toast.makeText(this, "All permissions granted", Toast.LENGTH_SHORT).show()
        } else {
            next.perm.request()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (built) refresh()
    }

    private fun refresh() {
        for (r in rows) {
            val ok = r.perm.granted()
            r.status.text = if (ok) "✓ Granted" else "✗ Not granted"
            r.button.isEnabled = !ok
        }
        val core = Access.isEnabled(this) && Settings.canDrawOverlays(this)
        banner.text = if (core) "Protection is ON" else "Protection is OFF. Grant the required permissions below."
    }

    companion object {
        private const val ADB_COMMAND =
            "adb shell pm grant com.reelguard.app android.permission.WRITE_SECURE_SETTINGS"
    }
}
