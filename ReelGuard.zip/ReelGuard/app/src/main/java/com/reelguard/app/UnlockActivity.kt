package com.reelguard.app

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton

/** Password prompt. Opened by the app itself and by the settings guard in BlockerService. */
class UnlockActivity : AppCompatActivity() {

    private lateinit var input: EditText
    private lateinit var status: TextView
    private lateinit var unlockBtn: MaterialButton
    private val handler = Handler(Looper.getMainLooper())

    private val ticker = object : Runnable {
        override fun run() {
            val commitLeft = Prefs.commitRemainingMs(this@UnlockActivity)
            if (commitLeft > 0) {
                input.isEnabled = false
                unlockBtn.isEnabled = false
                status.text = "Locked by your commitment. ${fmt(commitLeft)} left. " +
                    "The password can't open ReelGuard until then."
                handler.postDelayed(this, 1000)
                return
            }
            input.isEnabled = true

            val left = Prefs.lockoutRemainingMs(this@UnlockActivity)
            if (left > 0) {
                unlockBtn.isEnabled = false
                status.text = "Too many attempts. Try again in ${(left + 999) / 1000}s"
                handler.postDelayed(this, 500)
            } else {
                unlockBtn.isEnabled = true
                val t = status.text.toString()
                if (t.startsWith("Too many") || t.startsWith("Locked by")) status.text = ""
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Ui.dp(context, 24), Ui.dp(context, 64), Ui.dp(context, 24), Ui.dp(context, 24))
        }
        col.addView(Ui.text(this, "ReelGuard is locked", 24f, true))
        col.addView(
            Ui.text(this, "Enter your password to continue.", 14f)
                .apply { setPadding(0, Ui.dp(context, 8), 0, Ui.dp(context, 16)) }
        )
        input = Ui.passwordField(this, "Password")
        status = Ui.text(this, "", 14f)
        unlockBtn = Ui.button(this, "Unlock") { tryUnlock() }
        col.addView(input)
        col.addView(status)
        col.addView(unlockBtn)
        setContentView(col)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = goHome()
        })
    }

    override fun onResume() {
        super.onResume()
        handler.post(ticker)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(ticker)
    }

    private fun tryUnlock() {
        if (Prefs.isCommitted(this)) return
        if (Prefs.lockoutRemainingMs(this) > 0) return
        if (Prefs.checkPassword(this, input.text.toString())) {
            Prefs.unlock(this)
            finish()
        } else {
            Prefs.recordFailure(this)
            input.text.clear()
            status.text = "Wrong password"
            handler.post(ticker)
        }
    }

    private fun fmt(ms: Long): String {
        val minutes = (ms + 59_999) / 60_000
        val d = minutes / 1440
        val h = (minutes % 1440) / 60
        val m = minutes % 60
        return buildString {
            if (d > 0) append("${d}d ")
            if (d > 0 || h > 0) append("${h}h ")
            append("${m}m")
        }
    }

    private fun goHome() {
        startActivity(
            Intent(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_HOME)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        finishAffinity()
    }
}
