package com.reelguard.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Restarts the watchdog after reboot, app update, or an alarm-based restart. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Starter.start(context)
    }
}
