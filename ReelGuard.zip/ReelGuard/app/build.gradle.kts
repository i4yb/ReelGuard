plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.reelguard.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.reelguard.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 2
        versionName = "1.1"
    }

    // One fixed key for every build (local, Android Studio, CI) so updates install over each other.
    // Keep this project, and reelguard.jks, private.
    signingConfigs {
        create("reelguard") {
            storeFile = file("reelguard.jks")
            storePassword = "e65df0b9467acdc22b4a749e"
            keyAlias = "reelguard"
            keyPassword = "e65df0b9467acdc22b4a749e"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("reelguard")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("reelguard")
        }
    }

    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
}
