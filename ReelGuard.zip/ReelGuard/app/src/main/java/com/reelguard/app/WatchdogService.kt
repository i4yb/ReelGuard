package com.reelguard.app

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import androidx.core.content.ContextCompat

/** Starts the watchdog and, if Android refuses, schedules a retry. */
object Starter {
    const val ACTION_RESTART = "com.reelguard.app.RESTART"

    fun start(c: Context) {
        if (!Prefs.hasPassword(c)) return
        try {
            ContextCompat.startForegroundService(c, Intent(c, WatchdogService::class.java))
        } catch (e: Exception) {
            scheduleRestart(c)
        }
    }

    fun scheduleRestart(c: Context, delayMs: Long = 5000L) {
        try {
            val am = c.getSystemService(AlarmManager::class.java) ?: return
            val pi = PendingIntent.getBroadcast(
                c, 7,
                Intent(c, BootReceiver::class.java).setAction(ACTION_RESTART),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            am.setAndAllowWhileIdle(
                AlarmManager.ELAPSED_REALTIME_WAKEUP,
                SystemClock.elapsedRealtime() + delayMs,
                pi
            )
        } catch (e: Exception) {
            // nothing more we can do
        }
    }
}

/**
 * Foreground service whose job is to keep the app process alive and to switch the
 * accessibility service back on if it is turned off (needs the one-time ADB grant).
 */
class WatchdogService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private var lastAccessOn = true

    private val tick = object : Runnable {
        override fun run() {
            heal()
            handler.postDelayed(this, 3000L)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CHANNEL, "Protection", NotificationManager.IMPORTANCE_LOW)
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        lastAccessOn = Access.isEnabled(this)
        val n = buildNotification(lastAccessOn)
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
        handler.removeCallbacks(tick)
        handler.post(tick)
        return START_STICKY
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        Starter.scheduleRestart(this, 2000L)
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        Starter.scheduleRestart(this)
        super.onDestroy()
    }

    private fun heal() {
        var on = Access.isEnabled(this)
        // Don't fight the owner while they are unlocked and deliberately changing things.
        if (!on && Access.canWriteSecure(this) && !Prefs.isUnlocked(this)) {
            Access.enable(this)
            on = Access.isEnabled(this)
        }
        if (on != lastAccessOn) {
            lastAccessOn = on
            getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification(on))
        }
    }

    private fun buildNotification(accessOn: Boolean): Notification {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .setContentTitle(if (accessOn) "ReelGuard is protecting you" else "ReelGuard is OFF")
            .setContentText(
                if (accessOn) "Shorts and Reels are blocked."
                else "Tap to turn the accessibility service back on."
            )
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    companion object {
        private const val CHANNEL = "watchdog"
        private const val NOTIF_ID = 2
    }
}
