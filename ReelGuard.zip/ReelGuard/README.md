# ReelGuard 1.1

Android app that closes YouTube Shorts and Facebook Reels, turns Instagram into a messages-only app, and defends itself against being switched off, force-stopped or uninstalled on impulse. Settings sit behind a password you create on first launch.

## Get the APK

The APK is signed with the fixed key in `app/reelguard.jks`, so every build can be installed over the previous one. Keep this project private.

**Option A: GitHub builds it for you (no Android Studio)**
1. Create a **private** GitHub repository and push this whole folder to it (keep the hidden `.github` folder).
2. Open the repo's **Actions** tab > **Build APK** > **Run workflow**.
3. When it finishes (about 5 minutes), download the **ReelGuard-apk** artifact, unzip it, and you have `app-release.apk`.

**Option B: Android Studio**
1. Open this folder in Android Studio (Koala or newer), let it sync.
2. **Build > Build Bundle(s) / APK(s) > Build APK(s)**. The APK is in `app/build/outputs/apk/`.
   Or from a terminal: `./gradlew :app:assembleRelease` gives `app/build/outputs/apk/release/app-release.apk`.

**Install:** copy the APK to the phone, open it, allow "install unknown apps" for your file manager or browser when asked.

## First-run checklist

1. Open ReelGuard, create your password.
2. Tap **Grant next missing permission** until everything is ticked:
   - Accessibility (required). If greyed out: Settings > Apps > ReelGuard > ⋮ > **Allow restricted settings**.
   - Display over other apps (required).
   - Device administrator: blocks uninstalling until admin is turned off (needs your password).
   - Unrestricted battery + Notifications. On Xiaomi, Huawei, Oppo, Vivo and Samsung also allow **Autostart / Never sleeping apps** in the phone's own battery settings.
3. Optional but strongest, from a computer with USB debugging on:
   `adb shell pm grant com.reelguard.app android.permission.WRITE_SECURE_SETTINGS`
   Then ReelGuard switches its own accessibility service back on within seconds if anyone turns it off. (It waits while you are unlocked, so you can still change things on purpose.)

## What it blocks

- **YouTube**: the Shorts player and the Shorts tab.
- **Facebook / Facebook Lite**: the Reels tab and the full-screen Reels viewer.
- **Instagram DM-only mode** (each part has its own switch): feed, Reels tab, search and Explore are blocked; opening Instagram anywhere else sends you to messages; one reel sent by a friend can be opened but swiping to the next one closes it.

## How it defends itself

- **Always-on watchdog**: a foreground service keeps the process alive, restarts itself after reboot, app update, swipe-away or a kill, and shows a persistent "protecting you" notice (turns into "ReelGuard is OFF" if blocking stops).
- **Self-repair**: with the one-time ADB grant it re-enables the accessibility service if it is turned off.
- **Settings guard**: any Settings, app-manager or uninstall screen showing "ReelGuard" sends you Home and asks for the password. "Force stop?", "Uninstall?" and "Deactivate?" dialogs reached from that page are caught too (English, French, Arabic wording plus any dialog window).
- **Uninstall block**: device administrator is active, so Android refuses to uninstall until admin is removed, which is behind the guard.
- **Password**: salted PBKDF2, 5 wrong tries = 30 second lockout, 5 minute sliding unlock window.
- **Commitment lock** (in the app): lock everything for 1 hour, 24 hours or 7 days. During that time even the correct password does not open the app or the settings pages. You cannot shorten it. Use it deliberately.

## Honest limits

- Nothing on a phone is truly unremovable, and this app does not try to be. **Safe mode** disables third-party apps, so Settings > Device admin apps lets you turn ReelGuard's admin off and uninstall it. A factory reset also removes it. That is your escape hatch if you forget the password or a commitment lock is running.
- The guard recognises screens by their text, so unusual phone skins may need extra package names in `res/xml/accessibility_service_config.xml` and `Targets.GUARDED`.
- Blocking works by recognising screens through view ids and labels. YouTube, Facebook and Instagram rename these in updates, so a block can stop working after an app update. Facebook is the least predictable. To repair: build a debug variant, open the screen, read Logcat (tag `ReelGuard`), and edit the lists in `Detectors.kt`.
- Clearing the app's data wipes the password. The guard intercepts the "Clear storage" page, but treat that as best effort.
- Not for Google Play (Accessibility API policy). Sideload only.
- The code has not been compiled or run on a device by its author; expect to fix small things on the first build.
