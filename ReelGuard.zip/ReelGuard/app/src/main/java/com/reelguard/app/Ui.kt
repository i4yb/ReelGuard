package com.reelguard.app

import android.content.Context
import android.graphics.Typeface
import android.text.InputType
import android.widget.EditText
import android.widget.TextView
import com.google.android.material.button.MaterialButton

object Ui {
    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density).toInt()

    fun text(c: Context, t: String, sizeSp: Float = 15f, bold: Boolean = false): TextView =
        TextView(c).apply {
            text = t
            textSize = sizeSp
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    fun button(c: Context, t: String, onClick: () -> Unit): MaterialButton =
        MaterialButton(c).apply {
            text = t
            isAllCaps = false
            setOnClickListener { onClick() }
        }

    fun passwordField(c: Context, hintText: String): EditText =
        EditText(c).apply {
            hint = hintText
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setSingleLine()
        }
}
