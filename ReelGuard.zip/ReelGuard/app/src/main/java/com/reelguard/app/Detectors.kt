package com.reelguard.app

import android.view.accessibility.AccessibilityNodeInfo

object Targets {
    const val YT = "com.google.android.youtube"
    const val FB = "com.facebook.katana"
    const val FB_LITE = "com.facebook.lite"
    const val IG = "com.instagram.android"

    /** Settings / installer apps we watch so the password can't be bypassed. */
    val GUARDED = setOf(
        "com.android.settings",
        "com.google.android.packageinstaller",
        "com.android.packageinstaller",
        "com.samsung.android.packageinstaller",
        "com.google.android.permissioncontroller"
    )
}

/** A cheap summary of the current screen's accessibility tree. */
class Snapshot(
    val ids: List<String>,            // all view ids, lowercase, package prefix removed
    val selectedIds: Set<String>,     // ids of nodes that are selected AND visible
    val selectedDescs: List<String>,  // content descriptions of selected + visible nodes
    val className: String             // window class (only set on window-state events)
)

enum class IgScreen { DM, FEED, REELS, EXPLORE, REEL_VIEWER, OTHER }

/**
 * All the "what screen is this?" heuristics live here. The apps change their internal
 * view ids from time to time. When a block stops working after an app update, run a
 * debug build, watch Logcat for the tag "ReelGuard", and adjust the lists below.
 */
object Detectors {

    fun snapshot(root: AccessibilityNodeInfo, className: String, maxNodes: Int = 1200): Snapshot {
        val ids = ArrayList<String>()
        val selIds = HashSet<String>()
        val selDescs = ArrayList<String>()
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var count = 0
        while (queue.isNotEmpty() && count < maxNodes) {
            val n = queue.removeFirst()
            count++
            val id = n.viewIdResourceName?.substringAfter(":id/")?.lowercase()
            if (!id.isNullOrEmpty()) ids.add(id)
            if (n.isSelected && n.isVisibleToUser) {
                if (!id.isNullOrEmpty()) selIds.add(id)
                n.contentDescription?.toString()?.lowercase()?.let { selDescs.add(it) }
            }
            for (i in 0 until n.childCount) {
                n.getChild(i)?.let { queue.add(it) }
            }
        }
        return Snapshot(ids, selIds, selDescs, className)
    }

    // ---------------- YouTube ----------------

    fun isYouTubeShorts(s: Snapshot): Boolean {
        if (s.ids.any {
                it == "reel_recycler" ||
                    it.startsWith("reel_player") ||
                    it.startsWith("reel_watch") ||
                    it.startsWith("shorts_player")
            }) return true
        // The bottom "Shorts" tab is selected.
        return s.selectedDescs.any { it == "shorts" || it.startsWith("shorts,") || it.startsWith("shorts ") }
    }

    // ---------------- Facebook ----------------

    fun isFacebookReels(s: Snapshot): Boolean {
        if (s.className.lowercase().contains("reel")) return true
        if (s.ids.any {
                it.contains("reel") && (it.contains("viewer") || it.contains("player") || it.contains("pager"))
            }) return true
        return s.selectedDescs.any { it.startsWith("reels") }
    }

    // ---------------- Instagram ----------------

    // matches ids such as "direct_thread_...", "row_thread_composer_...", but not "action_bar_inbox_button"
    private val dmId = Regex("(^|_)(direct|thread)(_|$)")

    fun instagramScreen(s: Snapshot): IgScreen {
        val sel = s.selectedIds
        val viewer = s.ids.any {
            it.startsWith("clips_viewer") || it.startsWith("clips_video") || it.contains("reel_viewer")
        }
        return when {
            "clips_tab" in sel -> IgScreen.REELS
            "search_tab" in sel -> IgScreen.EXPLORE
            "feed_tab" in sel -> IgScreen.FEED
            viewer -> IgScreen.REEL_VIEWER
            "direct_tab" in sel || s.ids.any { dmId.containsMatchIn(it) } -> IgScreen.DM
            else -> IgScreen.OTHER
        }
    }
}
