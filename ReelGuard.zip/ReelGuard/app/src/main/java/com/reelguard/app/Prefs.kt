package com.reelguard.app

import android.content.Context
import android.util.Base64
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

object Prefs {
    const val YT_SHORTS = "yt_shorts"
    const val FB_REELS = "fb_reels"
    const val IG_ENABLED = "ig_enabled"
    const val IG_FEED = "ig_feed"
    const val IG_REELS = "ig_reels"
    const val IG_EXPLORE = "ig_explore"
    const val IG_DM_REELS = "ig_dm_reels"
    const val PROTECT = "protect_settings"

    private const val UNLOCK_MINUTES = 5L
    private const val MAX_FAILS = 5
    private const val LOCKOUT_MS = 30_000L

    private fun sp(c: Context) =
        c.applicationContext.getSharedPreferences("reelguard", Context.MODE_PRIVATE)

    fun getBool(c: Context, key: String, def: Boolean = true): Boolean = sp(c).getBoolean(key, def)

    fun setBool(c: Context, key: String, value: Boolean) {
        sp(c).edit().putBoolean(key, value).apply()
    }

    // ---- password ----

    fun hasPassword(c: Context): Boolean = sp(c).contains("pw_hash")

    private fun hash(pw: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(pw.toCharArray(), salt, 120_000, 256)
        return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
    }

    fun setPassword(c: Context, pw: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val h = hash(pw, salt)
        sp(c).edit()
            .putString("pw_salt", Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString("pw_hash", Base64.encodeToString(h, Base64.NO_WRAP))
            .apply()
    }

    fun checkPassword(c: Context, pw: String): Boolean {
        val s = sp(c)
        val salt = Base64.decode(s.getString("pw_salt", null) ?: return false, Base64.NO_WRAP)
        val stored = Base64.decode(s.getString("pw_hash", null) ?: return false, Base64.NO_WRAP)
        return MessageDigest.isEqual(stored, hash(pw, salt))
    }

    // ---- unlock window ----

    fun isUnlocked(c: Context): Boolean =
        !isCommitted(c) && System.currentTimeMillis() < sp(c).getLong("unlocked_until", 0L)

    // ---- commitment lock: nothing can be changed, even with the password, until it ends ----

    fun commitRemainingMs(c: Context): Long =
        (sp(c).getLong("commit_until", 0L) - System.currentTimeMillis()).coerceAtLeast(0L)

    fun isCommitted(c: Context): Boolean = commitRemainingMs(c) > 0L

    fun commit(c: Context, durationMs: Long) {
        // Never shorter than an existing commitment, never longer than 7 days.
        val capped = durationMs.coerceIn(0L, 7L * 24 * 60 * 60_000L)
        val until = maxOf(sp(c).getLong("commit_until", 0L), System.currentTimeMillis() + capped)
        sp(c).edit().putLong("commit_until", until).putLong("unlocked_until", 0L).apply()
    }

    fun unlock(c: Context) {
        if (isCommitted(c)) return
        sp(c).edit()
            .putLong("unlocked_until", System.currentTimeMillis() + UNLOCK_MINUTES * 60_000L)
            .putInt("fails", 0)
            .apply()
    }

    /** Called on user activity while unlocked, so the window slides. */
    fun extendUnlock(c: Context) {
        if (isUnlocked(c)) {
            sp(c).edit()
                .putLong("unlocked_until", System.currentTimeMillis() + UNLOCK_MINUTES * 60_000L)
                .apply()
        }
    }

    fun lock(c: Context) {
        sp(c).edit().putLong("unlocked_until", 0L).apply()
    }

    // ---- brute-force lockout ----

    fun recordFailure(c: Context) {
        val s = sp(c)
        val fails = s.getInt("fails", 0) + 1
        if (fails >= MAX_FAILS) {
            s.edit().putInt("fails", 0)
                .putLong("locked_until", System.currentTimeMillis() + LOCKOUT_MS).apply()
        } else {
            s.edit().putInt("fails", fails).apply()
        }
    }

    fun lockoutRemainingMs(c: Context): Long =
        (sp(c).getLong("locked_until", 0L) - System.currentTimeMillis()).coerceAtLeast(0L)
}
