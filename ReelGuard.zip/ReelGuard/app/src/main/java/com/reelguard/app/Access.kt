package com.reelguard.app

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.provider.Settings

/** Helpers for the accessibility service's on/off state. */
object Access {

    private fun me(c: Context) = ComponentName(c, BlockerService::class.java)

    fun isEnabled(c: Context): Boolean {
        val enabled = Settings.Secure.getString(
            c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val me = me(c)
        return enabled.split(':').any { ComponentName.unflattenFromString(it) == me }
    }

    /** True only after: adb shell pm grant com.reelguard.app android.permission.WRITE_SECURE_SETTINGS */
    fun canWriteSecure(c: Context): Boolean =
        c.checkSelfPermission(Manifest.permission.WRITE_SECURE_SETTINGS) == PackageManager.PERMISSION_GRANTED

    /** Switch the service back on. Needs [canWriteSecure]. */
    fun enable(c: Context): Boolean {
        if (!canWriteSecure(c)) return false
        return try {
            val cr = c.contentResolver
            val current = Settings.Secure.getString(cr, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES).orEmpty()
            val flat = me(c).flattenToString()
            val already = current.split(':').any { ComponentName.unflattenFromString(it) == me(c) }
            if (!already) {
                val updated = if (current.isEmpty()) flat else "$current:$flat"
                Settings.Secure.putString(cr, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, updated)
            }
            Settings.Secure.putInt(cr, Settings.Secure.ACCESSIBILITY_ENABLED, 1)
            true
        } catch (e: SecurityException) {
            false
        }
    }
}
