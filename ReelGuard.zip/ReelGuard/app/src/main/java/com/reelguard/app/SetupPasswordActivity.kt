package com.reelguard.app

import android.content.Intent
import android.os.Bundle
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/** First run: create the password. Also used to change it (only while unlocked). */
class SetupPasswordActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)

        val changing = Prefs.hasPassword(this)
        if (changing && !Prefs.isUnlocked(this)) {
            finish()
            return
        }

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Ui.dp(context, 24), Ui.dp(context, 48), Ui.dp(context, 24), Ui.dp(context, 24))
        }
        col.addView(Ui.text(this, if (changing) "Change password" else "Create a password", 24f, true))
        col.addView(
            Ui.text(
                this,
                "This password protects ReelGuard's settings and stops it from being switched off or uninstalled on impulse. " +
                    "Pick something you won't type without thinking, or ask a friend to choose it. There is no recovery.",
                14f
            ).apply { setPadding(0, Ui.dp(context, 12), 0, Ui.dp(context, 16)) }
        )

        val p1 = Ui.passwordField(this, "New password (6+ characters)")
        val p2 = Ui.passwordField(this, "Repeat password")
        col.addView(p1)
        col.addView(p2)

        col.addView(Ui.button(this, "Save password") {
            val a = p1.text.toString()
            val b = p2.text.toString()
            when {
                a.length < 6 -> Toast.makeText(this, "Use at least 6 characters", Toast.LENGTH_SHORT).show()
                a != b -> Toast.makeText(this, "Passwords don't match", Toast.LENGTH_SHORT).show()
                else -> {
                    Prefs.setPassword(this, a)
                    Prefs.unlock(this)
                    if (!changing) startActivity(Intent(this, MainActivity::class.java))
                    finish()
                }
            }
        })

        setContentView(ScrollView(this).apply { addView(col) })
    }
}
